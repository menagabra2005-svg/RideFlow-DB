-- ============================================================
--  RIDE-HAILING SYSTEM — SQL SERVER IMPLEMENTATION
--  Based on ER Diagram + 3NF Normalized Schema
--  All 13 Tables | Constraints | Indexes | Views | Procedures
-- ============================================================

USE master;
GO

-- Drop and recreate database
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'RideHailingDB')
BEGIN
    ALTER DATABASE RideHailingDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE RideHailingDB;
END
GO

CREATE DATABASE RideHailingDB;
GO

USE RideHailingDB;
GO

-- ============================================================
--  SECTION 1 — TABLE CREATION (3NF Schema)
-- ============================================================

-- ─────────────────────────────────────────────
--  1. User  (Supertype)
-- ─────────────────────────────────────────────
CREATE TABLE [User] (
    UserID   INT           IDENTITY(1,1) PRIMARY KEY,
    Name     NVARCHAR(100) NOT NULL,
    Email    NVARCHAR(150) NOT NULL UNIQUE,   -- candidate key
    DOB      DATE          NOT NULL,
    -- Age is DERIVED: computed from DOB, not stored
    -- Phone is MULTI-VALUED: stored in UserPhone table
);
GO

-- ─────────────────────────────────────────────
--  2. UserPhone  (Multi-valued attribute of User)
-- ─────────────────────────────────────────────
CREATE TABLE UserPhone (
    UserID  INT           NOT NULL,
    Phone   NVARCHAR(20)  NOT NULL,
    CONSTRAINT PK_UserPhone PRIMARY KEY (UserID, Phone),
    CONSTRAINT FK_UserPhone_User FOREIGN KEY (UserID)
        REFERENCES [User](UserID) ON DELETE CASCADE
);
GO

-- ─────────────────────────────────────────────
--  3. Admin  (Subtype of User — Disjoint, Total)
-- ─────────────────────────────────────────────
CREATE TABLE Admin (
    UserID  INT NOT NULL,
    CONSTRAINT PK_Admin PRIMARY KEY (UserID),
    CONSTRAINT FK_Admin_User FOREIGN KEY (UserID)
        REFERENCES [User](UserID) ON DELETE CASCADE
);
GO

-- ─────────────────────────────────────────────
--  4. AdminPermissions  (Multi-valued attribute of Admin)
-- ─────────────────────────────────────────────
CREATE TABLE AdminPermissions (
    UserID      INT           NOT NULL,
    Permission  NVARCHAR(100) NOT NULL,
    CONSTRAINT PK_AdminPermissions PRIMARY KEY (UserID, Permission),
    CONSTRAINT FK_AdminPerm_Admin FOREIGN KEY (UserID)
        REFERENCES Admin(UserID) ON DELETE CASCADE
);
GO

-- ─────────────────────────────────────────────
--  5. Rider  (Subtype of User — Disjoint, Total)
-- ─────────────────────────────────────────────
CREATE TABLE Rider (
    UserID                  INT           NOT NULL,
    PreferredPaymentMethod  NVARCHAR(50)  NULL,   -- Optional
    -- Rating is DERIVED: computed from feedback, not stored
    CONSTRAINT PK_Rider PRIMARY KEY (UserID),
    CONSTRAINT FK_Rider_User FOREIGN KEY (UserID)
        REFERENCES [User](UserID) ON DELETE CASCADE,
    CONSTRAINT CHK_Rider_PayMethod CHECK (
        PreferredPaymentMethod IN ('Cash', 'Card', 'Wallet') OR PreferredPaymentMethod IS NULL
    )
);
GO

-- ─────────────────────────────────────────────
--  6. Driver  (Supertype)
-- ─────────────────────────────────────────────
CREATE TABLE Driver (
    DriverID       INT           IDENTITY(1,1) PRIMARY KEY,
    Name           NVARCHAR(100) NOT NULL,
    LicenseNumber  NVARCHAR(50)  NOT NULL UNIQUE,
    Status         NVARCHAR(20)  NOT NULL DEFAULT 'Available',
    -- Rating is DERIVED: computed from feedback, not stored
    -- Phone is MULTI-VALUED: stored in DriverPhone table
    CONSTRAINT CHK_Driver_Status CHECK (Status IN ('Available', 'Busy'))
);
GO

-- ─────────────────────────────────────────────
--  7. DriverPhone  (Multi-valued attribute of Driver)
-- ─────────────────────────────────────────────
CREATE TABLE DriverPhone (
    DriverID  INT           NOT NULL,
    Phone     NVARCHAR(20)  NOT NULL,
    CONSTRAINT PK_DriverPhone PRIMARY KEY (DriverID, Phone),
    CONSTRAINT FK_DriverPhone_Driver FOREIGN KEY (DriverID)
        REFERENCES Driver(DriverID) ON DELETE CASCADE
);
GO

-- ─────────────────────────────────────────────
--  8. FullTimeDriver  (Subtype of Driver)
-- ─────────────────────────────────────────────
CREATE TABLE FullTimeDriver (
    DriverID  INT            NOT NULL,
    Salary    DECIMAL(10, 2) NOT NULL,
    CONSTRAINT PK_FullTimeDriver PRIMARY KEY (DriverID),
    CONSTRAINT FK_FTDriver_Driver FOREIGN KEY (DriverID)
        REFERENCES Driver(DriverID) ON DELETE CASCADE,
    CONSTRAINT CHK_FTDriver_Salary CHECK (Salary > 0)
);
GO

-- ─────────────────────────────────────────────
--  9. PartTimeDriver  (Subtype of Driver)
-- ─────────────────────────────────────────────
CREATE TABLE PartTimeDriver (
    DriverID      INT           NOT NULL,
    WorkingHours  NVARCHAR(50)  NULL,   -- e.g. "Mon-Fri 9AM-5PM"
    CONSTRAINT PK_PartTimeDriver PRIMARY KEY (DriverID),
    CONSTRAINT FK_PTDriver_Driver FOREIGN KEY (DriverID)
        REFERENCES Driver(DriverID) ON DELETE CASCADE
);
GO

-- ─────────────────────────────────────────────
--  10. Request
-- ─────────────────────────────────────────────
CREATE TABLE Request (
    RequestID       INT           IDENTITY(1,1) PRIMARY KEY,
    RequestTime     DATETIME      NOT NULL DEFAULT GETDATE(),
    PickupLocation  NVARCHAR(255) NOT NULL,
    DropoffLocation NVARCHAR(255) NOT NULL,
    Status          NVARCHAR(20)  NOT NULL DEFAULT 'Pending',
    RiderID         INT           NOT NULL,   -- FK → Rider
    CONSTRAINT FK_Request_Rider FOREIGN KEY (RiderID)
        REFERENCES Rider(UserID),
    CONSTRAINT CHK_Request_Status CHECK (Status IN ('Pending', 'Accepted', 'Rejected'))
);
GO

-- ─────────────────────────────────────────────
--  11. Trip
-- ─────────────────────────────────────────────
CREATE TABLE Trip (
    TripID         INT           IDENTITY(1,1) PRIMARY KEY,
    StartLocation  NVARCHAR(255) NOT NULL,
    EndLocation    NVARCHAR(255) NOT NULL,
    -- Distance is DERIVED: computed from Start/End, not stored
    StartTime      DATETIME      NOT NULL,
    EndTime        DATETIME      NULL,        -- Optional (NULL while ongoing)
    Status         NVARCHAR(20)  NOT NULL DEFAULT 'Ongoing',
    RequestID      INT           NOT NULL UNIQUE,  -- 1:1 with Request
    DriverID       INT           NOT NULL,
    CONSTRAINT FK_Trip_Request FOREIGN KEY (RequestID)
        REFERENCES Request(RequestID),
    CONSTRAINT FK_Trip_Driver FOREIGN KEY (DriverID)
        REFERENCES Driver(DriverID),
    CONSTRAINT CHK_Trip_Status CHECK (Status IN ('Ongoing', 'Completed', 'Cancelled')),
    CONSTRAINT CHK_Trip_Times CHECK (EndTime IS NULL OR EndTime > StartTime)
);
GO

-- ─────────────────────────────────────────────
--  12. Payment
-- ─────────────────────────────────────────────
CREATE TABLE Payment (
    PaymentID      INT            IDENTITY(1,1) PRIMARY KEY,
    Amount         DECIMAL(10, 2) NOT NULL,
    PaymentMethod  NVARCHAR(20)   NOT NULL,
    PaymentStatus  NVARCHAR(20)   NOT NULL DEFAULT 'Pending',
    PaymentDate    DATETIME       NULL,       -- Optional
    TripID         INT            NOT NULL UNIQUE,  -- 1:1 with Trip
    CONSTRAINT FK_Payment_Trip FOREIGN KEY (TripID)
        REFERENCES Trip(TripID),
    CONSTRAINT CHK_Payment_Method CHECK (PaymentMethod IN ('Cash', 'Card', 'Wallet')),
    CONSTRAINT CHK_Payment_Status CHECK (PaymentStatus IN ('Paid', 'Pending')),
    CONSTRAINT CHK_Payment_Amount CHECK (Amount > 0)
);
GO

-- ─────────────────────────────────────────────
--  13. TripFeedback  (Weak Entity)
--      Full PK = (TripID, FeedbackID)
-- ─────────────────────────────────────────────
CREATE TABLE TripFeedback (
    TripID      INT           NOT NULL,   -- Part of composite PK + Identifying FK
    FeedbackID  INT           NOT NULL,   -- Partial key (unique only within a Trip)
    Rating      TINYINT       NOT NULL,
    Comment     NVARCHAR(500) NULL,       -- Optional
    CONSTRAINT PK_TripFeedback PRIMARY KEY (TripID, FeedbackID),
    CONSTRAINT FK_TripFeedback_Trip FOREIGN KEY (TripID)
        REFERENCES Trip(TripID) ON DELETE CASCADE,
    CONSTRAINT CHK_Feedback_Rating CHECK (Rating BETWEEN 1 AND 5)
);
GO


-- ============================================================
--  SECTION 2 — INDEXES
--  (Beyond PKs — for common query patterns)
-- ============================================================

-- Fast lookup of all requests by a rider
CREATE INDEX IX_Request_RiderID     ON Request(RiderID);

-- Fast lookup of all trips by a driver
CREATE INDEX IX_Trip_DriverID       ON Trip(DriverID);

-- Fast lookup of trips by status
CREATE INDEX IX_Trip_Status         ON Trip(Status);

-- Fast lookup of requests by status
CREATE INDEX IX_Request_Status      ON Request(Status);

-- Fast lookup of payments by status
CREATE INDEX IX_Payment_Status      ON Payment(PaymentStatus);

-- Fast lookup of drivers by status
CREATE INDEX IX_Driver_Status       ON Driver(Status);

-- Email lookup (already unique but explicit for clarity)
CREATE INDEX IX_User_Email          ON [User](Email);
GO


-- ============================================================
--  SECTION 3 — COMPUTED / DERIVED COLUMNS AS VIEWS
--  (Age, Driver Rating, Rider Rating, Trip Distance)
-- ============================================================

-- ── Derived: User Age ───────────────────────────────────────
CREATE VIEW vw_UserWithAge AS
SELECT
    UserID,
    Name,
    Email,
    DOB,
    DATEDIFF(YEAR, DOB, GETDATE())
        - CASE WHEN MONTH(DOB) > MONTH(GETDATE())
                 OR (MONTH(DOB) = MONTH(GETDATE()) AND DAY(DOB) > DAY(GETDATE()))
               THEN 1 ELSE 0 END  AS Age
FROM [User];
GO

-- ── Derived: Driver Rating (avg of all trip feedbacks) ──────
CREATE VIEW vw_DriverRating AS
SELECT
    d.DriverID,
    d.Name,
    d.Status,
    ROUND(AVG(CAST(tf.Rating AS FLOAT)), 2) AS Rating,
    COUNT(tf.Rating)                         AS TotalReviews
FROM Driver d
LEFT JOIN Trip    t  ON t.DriverID = d.DriverID
LEFT JOIN TripFeedback tf ON tf.TripID = t.TripID
GROUP BY d.DriverID, d.Name, d.Status;
GO

-- ── Derived: Rider Rating (avg rating received as passenger) ─
CREATE VIEW vw_RiderRating AS
SELECT
    r.UserID,
    u.Name,
    ROUND(AVG(CAST(tf.Rating AS FLOAT)), 2) AS Rating,
    COUNT(tf.Rating)                         AS TotalReviews
FROM Rider r
JOIN [User]  u  ON u.UserID  = r.UserID
LEFT JOIN Request req ON req.RiderID = r.UserID
LEFT JOIN Trip    t   ON t.RequestID = req.RequestID
LEFT JOIN TripFeedback tf ON tf.TripID = t.TripID
GROUP BY r.UserID, u.Name;
GO

-- ── Full Trip Details (with all related info) ────────────────
CREATE VIEW vw_TripDetails AS
SELECT
    t.TripID,
    t.StartLocation,
    t.EndLocation,
    t.StartTime,
    t.EndTime,
    t.Status                                  AS TripStatus,
    DATEDIFF(MINUTE, t.StartTime, t.EndTime)  AS DurationMinutes,
    -- Rider info
    u.Name                                    AS RiderName,
    u.Email                                   AS RiderEmail,
    -- Driver info
    d.Name                                    AS DriverName,
    d.LicenseNumber,
    -- Payment info
    p.Amount,
    p.PaymentMethod,
    p.PaymentStatus,
    -- Feedback
    AVG(CAST(tf.Rating AS FLOAT))             AS AvgFeedbackRating
FROM Trip t
JOIN Request  req ON req.RequestID = t.RequestID
JOIN Rider    r   ON r.UserID      = req.RiderID
JOIN [User]   u   ON u.UserID      = r.UserID
JOIN Driver   d   ON d.DriverID    = t.DriverID
LEFT JOIN Payment      p   ON p.TripID  = t.TripID
LEFT JOIN TripFeedback tf  ON tf.TripID = t.TripID
GROUP BY
    t.TripID, t.StartLocation, t.EndLocation,
    t.StartTime, t.EndTime, t.Status,
    u.Name, u.Email, d.Name, d.LicenseNumber,
    p.Amount, p.PaymentMethod, p.PaymentStatus;
GO


-- ============================================================
--  SECTION 4 — STORED PROCEDURES
-- ============================================================

-- ── SP 1: Register a new User (as Rider) ────────────────────
CREATE PROCEDURE sp_RegisterRider
    @Name                  NVARCHAR(100),
    @Email                 NVARCHAR(150),
    @DOB                   DATE,
    @Phone                 NVARCHAR(20),
    @PreferredPaymentMethod NVARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        -- Insert into User
        INSERT INTO [User] (Name, Email, DOB)
        VALUES (@Name, @Email, @DOB);

        DECLARE @NewUserID INT = SCOPE_IDENTITY();

        -- Insert into Rider subtype
        INSERT INTO Rider (UserID, PreferredPaymentMethod)
        VALUES (@NewUserID, @PreferredPaymentMethod);

        -- Insert phone (multi-valued)
        IF @Phone IS NOT NULL
            INSERT INTO UserPhone (UserID, Phone) VALUES (@NewUserID, @Phone);

        COMMIT TRANSACTION;
        SELECT @NewUserID AS NewRiderID;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- ── SP 2: Register a new Driver (as Full-Time) ───────────────
CREATE PROCEDURE sp_RegisterFullTimeDriver
    @Name          NVARCHAR(100),
    @LicenseNumber NVARCHAR(50),
    @Phone         NVARCHAR(20),
    @Salary        DECIMAL(10,2)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        INSERT INTO Driver (Name, LicenseNumber, Status)
        VALUES (@Name, @LicenseNumber, 'Available');

        DECLARE @NewDriverID INT = SCOPE_IDENTITY();

        INSERT INTO FullTimeDriver (DriverID, Salary)
        VALUES (@NewDriverID, @Salary);

        IF @Phone IS NOT NULL
            INSERT INTO DriverPhone (DriverID, Phone) VALUES (@NewDriverID, @Phone);

        COMMIT TRANSACTION;
        SELECT @NewDriverID AS NewDriverID;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- ── SP 3: Register a new Driver (as Part-Time) ───────────────
CREATE PROCEDURE sp_RegisterPartTimeDriver
    @Name          NVARCHAR(100),
    @LicenseNumber NVARCHAR(50),
    @Phone         NVARCHAR(20),
    @WorkingHours  NVARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        INSERT INTO Driver (Name, LicenseNumber, Status)
        VALUES (@Name, @LicenseNumber, 'Available');

        DECLARE @NewDriverID INT = SCOPE_IDENTITY();

        INSERT INTO PartTimeDriver (DriverID, WorkingHours)
        VALUES (@NewDriverID, @WorkingHours);

        IF @Phone IS NOT NULL
            INSERT INTO DriverPhone (DriverID, Phone) VALUES (@NewDriverID, @Phone);

        COMMIT TRANSACTION;
        SELECT @NewDriverID AS NewDriverID;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- ── SP 4: Create a Ride Request ──────────────────────────────
CREATE PROCEDURE sp_CreateRequest
    @RiderID        INT,
    @PickupLocation NVARCHAR(255),
    @DropoffLocation NVARCHAR(255)
AS
BEGIN
    SET NOCOUNT ON;

    -- Validate Rider exists
    IF NOT EXISTS (SELECT 1 FROM Rider WHERE UserID = @RiderID)
    BEGIN
        RAISERROR('Rider not found.', 16, 1);
        RETURN;
    END

    INSERT INTO Request (RequestTime, PickupLocation, DropoffLocation, Status, RiderID)
    VALUES (GETDATE(), @PickupLocation, @DropoffLocation, 'Pending', @RiderID);

    SELECT SCOPE_IDENTITY() AS NewRequestID;
END;
GO

-- ── SP 5: Accept a Request → Create a Trip ───────────────────
CREATE PROCEDURE sp_AcceptRequest
    @RequestID INT,
    @DriverID  INT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        -- Validate request is pending
        IF NOT EXISTS (SELECT 1 FROM Request WHERE RequestID = @RequestID AND Status = 'Pending')
        BEGIN
            RAISERROR('Request not found or not in Pending status.', 16, 1);
            ROLLBACK; RETURN;
        END

        -- Validate driver is available
        IF NOT EXISTS (SELECT 1 FROM Driver WHERE DriverID = @DriverID AND Status = 'Available')
        BEGIN
            RAISERROR('Driver not found or not available.', 16, 1);
            ROLLBACK; RETURN;
        END

        -- Mark request as Accepted
        UPDATE Request SET Status = 'Accepted' WHERE RequestID = @RequestID;

        -- Get locations from request
        DECLARE @Pickup  NVARCHAR(255),
                @Dropoff NVARCHAR(255);
        SELECT @Pickup = PickupLocation, @Dropoff = DropoffLocation
        FROM Request WHERE RequestID = @RequestID;

        -- Create the Trip
        INSERT INTO Trip (StartLocation, EndLocation, StartTime, Status, RequestID, DriverID)
        VALUES (@Pickup, @Dropoff, GETDATE(), 'Ongoing', @RequestID, @DriverID);

        DECLARE @NewTripID INT = SCOPE_IDENTITY();

        -- Mark driver as Busy
        UPDATE Driver SET Status = 'Busy' WHERE DriverID = @DriverID;

        COMMIT TRANSACTION;
        SELECT @NewTripID AS NewTripID;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- ── SP 6: Complete a Trip ────────────────────────────────────
CREATE PROCEDURE sp_CompleteTrip
    @TripID        INT,
    @Amount        DECIMAL(10,2),
    @PaymentMethod NVARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        -- Validate trip is ongoing
        IF NOT EXISTS (SELECT 1 FROM Trip WHERE TripID = @TripID AND Status = 'Ongoing')
        BEGIN
            RAISERROR('Trip not found or not ongoing.', 16, 1);
            ROLLBACK; RETURN;
        END

        -- Get DriverID from trip
        DECLARE @DriverID INT;
        SELECT @DriverID = DriverID FROM Trip WHERE TripID = @TripID;

        -- Complete the trip
        UPDATE Trip
        SET Status = 'Completed', EndTime = GETDATE()
        WHERE TripID = @TripID;

        -- Create Payment record
        INSERT INTO Payment (Amount, PaymentMethod, PaymentStatus, PaymentDate, TripID)
        VALUES (@Amount, @PaymentMethod, 'Paid', GETDATE(), @TripID);

        -- Set driver back to Available
        UPDATE Driver SET Status = 'Available' WHERE DriverID = @DriverID;

        COMMIT TRANSACTION;
        SELECT SCOPE_IDENTITY() AS NewPaymentID;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- ── SP 7: Submit Feedback for a Trip ─────────────────────────
CREATE PROCEDURE sp_SubmitFeedback
    @TripID  INT,
    @Rating  TINYINT,
    @Comment NVARCHAR(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Validate trip is completed
    IF NOT EXISTS (SELECT 1 FROM Trip WHERE TripID = @TripID AND Status = 'Completed')
    BEGIN
        RAISERROR('Feedback can only be submitted for completed trips.', 16, 1);
        RETURN;
    END

    -- Auto-increment FeedbackID within the trip (partial key)
    DECLARE @NextFeedbackID INT;
    SELECT @NextFeedbackID = ISNULL(MAX(FeedbackID), 0) + 1
    FROM TripFeedback WHERE TripID = @TripID;

    INSERT INTO TripFeedback (TripID, FeedbackID, Rating, Comment)
    VALUES (@TripID, @NextFeedbackID, @Rating, @Comment);

    SELECT @NextFeedbackID AS NewFeedbackID;
END;
GO

-- ── SP 8: Get Available Drivers ──────────────────────────────
CREATE PROCEDURE sp_GetAvailableDrivers
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        d.DriverID,
        d.Name,
        d.LicenseNumber,
        d.Status,
        CASE
            WHEN ft.DriverID IS NOT NULL THEN 'Full-Time'
            WHEN pt.DriverID IS NOT NULL THEN 'Part-Time'
        END AS DriverType,
        vr.Rating,
        vr.TotalReviews,
        STRING_AGG(dp.Phone, ', ') AS Phones
    FROM Driver d
    LEFT JOIN FullTimeDriver ft ON ft.DriverID = d.DriverID
    LEFT JOIN PartTimeDriver pt ON pt.DriverID = d.DriverID
    LEFT JOIN vw_DriverRating vr ON vr.DriverID = d.DriverID
    LEFT JOIN DriverPhone dp     ON dp.DriverID = d.DriverID
    WHERE d.Status = 'Available'
    GROUP BY d.DriverID, d.Name, d.LicenseNumber, d.Status,
             ft.DriverID, pt.DriverID, vr.Rating, vr.TotalReviews;
END;
GO

-- ── SP 9: Get Rider Trip History ─────────────────────────────
CREATE PROCEDURE sp_GetRiderHistory
    @RiderID INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        t.TripID,
        t.StartLocation,
        t.EndLocation,
        t.StartTime,
        t.EndTime,
        t.Status,
        DATEDIFF(MINUTE, t.StartTime, t.EndTime) AS DurationMinutes,
        d.Name       AS DriverName,
        p.Amount,
        p.PaymentMethod,
        p.PaymentStatus,
        AVG(CAST(tf.Rating AS FLOAT)) AS YourRating
    FROM Request req
    JOIN Trip    t  ON t.RequestID = req.RequestID
    JOIN Driver  d  ON d.DriverID  = t.DriverID
    LEFT JOIN Payment      p  ON p.TripID  = t.TripID
    LEFT JOIN TripFeedback tf ON tf.TripID = t.TripID
    WHERE req.RiderID = @RiderID
    GROUP BY
        t.TripID, t.StartLocation, t.EndLocation,
        t.StartTime, t.EndTime, t.Status,
        d.Name, p.Amount, p.PaymentMethod, p.PaymentStatus
    ORDER BY t.StartTime DESC;
END;
GO


-- ============================================================
--  SECTION 5 — SAMPLE DATA
--  Scale: 20–50 records per main table
-- ============================================================

-- ── Users (20 users: 17 Riders + 2 Admins + 1 shared) ───────
INSERT INTO [User] (Name, Email, DOB) VALUES
    ('Ahmed Hassan',      'ahmed@mail.com',      '1995-03-15'),  -- UserID 1
    ('Sara Mahmoud',      'sara@mail.com',       '1998-07-22'),  -- UserID 2
    ('Omar Khaled',       'omar@mail.com',       '1990-11-05'),  -- UserID 3
    ('Nour Eldin',        'nour@mail.com',       '2000-01-30'),  -- UserID 4
    ('Layla Ibrahim',     'layla@mail.com',      '1997-05-18'),  -- UserID 5
    ('Youssef Adel',      'youssef@mail.com',    '1993-09-25'),  -- UserID 6
    ('Mona Sayed',        'mona@mail.com',       '1996-12-11'),  -- UserID 7
    ('Kareem Nasser',     'kareem@mail.com',     '1991-04-07'),  -- UserID 8
    ('Dina Fouad',        'dina@mail.com',       '1999-08-14'),  -- UserID 9
    ('Bassem Gamal',      'bassem@mail.com',     '1994-02-28'),  -- UserID 10
    ('Rania Mostafa',     'rania@mail.com',       '2001-06-03'),  -- UserID 11
    ('Tarek Fathy',       'tarek@mail.com',      '1988-10-19'),  -- UserID 12
    ('Heba Mansour',      'heba@mail.com',       '2002-03-22'),  -- UserID 13
    ('Sherif Lotfy',      'sherif@mail.com',     '1992-07-30'),  -- UserID 14
    ('Asmaa Ramadan',     'asmaa@mail.com',      '1997-11-09'),  -- UserID 15
    ('Mahmoud Zakaria',   'mahmoud@mail.com',    '1989-01-17'),  -- UserID 16
    ('Eman Waheed',       'eman@mail.com',        '2000-04-25'),  -- UserID 17
    ('Admin User',        'admin@system.com',    '1985-06-10'),  -- UserID 18
    ('Admin Two',         'admin2@system.com',   '1980-09-01'),  -- UserID 19
    ('Salma Kamal',       'salma@mail.com',      '1998-12-05');  -- UserID 20

-- ── Riders (17 riders: UserIDs 1–17 + 20) ───────────────────
INSERT INTO Rider (UserID, PreferredPaymentMethod) VALUES
    (1,  'Card'),
    (2,  'Wallet'),
    (3,  'Cash'),
    (4,  NULL),
    (5,  'Card'),
    (6,  'Cash'),
    (7,  'Wallet'),
    (8,  'Card'),
    (9,  NULL),
    (10, 'Cash'),
    (11, 'Wallet'),
    (12, 'Card'),
    (13, 'Cash'),
    (14, 'Wallet'),
    (15, NULL),
    (16, 'Card'),
    (17, 'Cash'),
    (20, 'Wallet');

-- ── Admins ───────────────────────────────────────────────────
INSERT INTO Admin (UserID) VALUES (18), (19);

INSERT INTO AdminPermissions (UserID, Permission) VALUES
    (18, 'ManageDrivers'),
    (18, 'ManageRiders'),
    (18, 'ViewReports'),
    (19, 'ViewReports'),
    (19, 'ManageRiders');

-- ── UserPhone ─────────────────────────────────────────────────
INSERT INTO UserPhone (UserID, Phone) VALUES
    (1,  '+20-100-111-2222'),
    (1,  '+20-100-333-4444'),  -- Ahmed has 2 phones
    (2,  '+20-111-555-6666'),
    (3,  '+20-122-777-8888'),
    (4,  '+20-100-999-0000'),
    (5,  '+20-101-100-1001'),
    (6,  '+20-101-200-2002'),
    (7,  '+20-101-300-3003'),
    (8,  '+20-101-400-4004'),
    (9,  '+20-101-500-5005'),
    (10, '+20-101-600-6006'),
    (11, '+20-101-700-7007'),
    (12, '+20-101-800-8008'),
    (13, '+20-101-900-9009'),
    (14, '+20-102-100-1001'),
    (15, '+20-102-200-2002'),
    (16, '+20-102-300-3003'),
    (17, '+20-102-400-4004'),
    (20, '+20-102-500-5005');

-- ── Drivers (20 drivers) ─────────────────────────────────────
INSERT INTO Driver (Name, LicenseNumber, Status) VALUES
    ('Karim Samir',       'LIC-001', 'Available'),  -- DriverID 1  (Full-Time)
    ('Mohamed Farouk',    'LIC-002', 'Available'),  -- DriverID 2  (Full-Time)
    ('Tarek Adel',        'LIC-003', 'Available'),  -- DriverID 3  (Part-Time)
    ('Hassan Ali',        'LIC-004', 'Available'),  -- DriverID 4  (Part-Time)
    ('Walid Sobhy',       'LIC-005', 'Available'),  -- DriverID 5  (Full-Time)
    ('Amr Gaber',         'LIC-006', 'Busy'),       -- DriverID 6  (Full-Time)
    ('Sayed Ragab',       'LIC-007', 'Available'),  -- DriverID 7  (Part-Time)
    ('Adel Morsi',        'LIC-008', 'Busy'),       -- DriverID 8  (Full-Time)
    ('Fathy Nour',        'LIC-009', 'Available'),  -- DriverID 9  (Part-Time)
    ('Ibrahim Sabry',     'LIC-010', 'Available'),  -- DriverID 10 (Full-Time)
    ('Maged Hamdy',       'LIC-011', 'Busy'),       -- DriverID 11 (Full-Time)
    ('Nader Shawky',      'LIC-012', 'Available'),  -- DriverID 12 (Part-Time)
    ('Osama Helmy',       'LIC-013', 'Available'),  -- DriverID 13 (Part-Time)
    ('Ramzy Atef',        'LIC-014', 'Available'),  -- DriverID 14 (Full-Time)
    ('Samir Badawi',      'LIC-015', 'Busy'),       -- DriverID 15 (Part-Time)
    ('Tamer Zaki',        'LIC-016', 'Available'),  -- DriverID 16 (Full-Time)
    ('Usama Farid',       'LIC-017', 'Available'),  -- DriverID 17 (Part-Time)
    ('Wael Saleh',        'LIC-018', 'Busy'),       -- DriverID 18 (Full-Time)
    ('Yasser Hamid',      'LIC-019', 'Available'),  -- DriverID 19 (Part-Time)
    ('Ziad Mohsen',       'LIC-020', 'Available');  -- DriverID 20 (Full-Time)

-- ── FullTimeDriver (11 full-time) ────────────────────────────
INSERT INTO FullTimeDriver (DriverID, Salary) VALUES
    (1,  8000.00),
    (2,  7500.00),
    (5,  8200.00),
    (6,  7800.00),
    (8,  9000.00),
    (10, 7600.00),
    (11, 8500.00),
    (14, 7900.00),
    (16, 8100.00),
    (18, 7700.00),
    (20, 8300.00);

-- ── PartTimeDriver (9 part-time) ─────────────────────────────
INSERT INTO PartTimeDriver (DriverID, WorkingHours) VALUES
    (3,  'Mon-Fri 6PM-12AM'),
    (4,  'Weekends Only'),
    (7,  'Mon-Wed 8AM-2PM'),
    (9,  'Thu-Fri 4PM-10PM'),
    (12, 'Weekends 9AM-6PM'),
    (13, 'Mon-Thu 7AM-1PM'),
    (15, 'Fri-Sat 5PM-11PM'),
    (17, 'Tue-Thu 10AM-4PM'),
    (19, 'Weekends 8AM-8PM');

-- ── DriverPhone ───────────────────────────────────────────────
INSERT INTO DriverPhone (DriverID, Phone) VALUES
    (1,  '+20-122-001-0001'),
    (2,  '+20-122-002-0002'),
    (2,  '+20-100-002-0003'),  -- Mohamed has 2 phones
    (3,  '+20-122-003-0003'),
    (4,  '+20-122-004-0004'),
    (5,  '+20-122-005-0005'),
    (6,  '+20-122-006-0006'),
    (7,  '+20-122-007-0007'),
    (8,  '+20-122-008-0008'),
    (9,  '+20-122-009-0009'),
    (10, '+20-122-010-0010'),
    (11, '+20-122-011-0011'),
    (12, '+20-122-012-0012'),
    (13, '+20-122-013-0013'),
    (14, '+20-122-014-0014'),
    (15, '+20-122-015-0015'),
    (16, '+20-122-016-0016'),
    (17, '+20-122-017-0017'),
    (18, '+20-122-018-0018'),
    (19, '+20-122-019-0019'),
    (20, '+20-122-020-0020');

-- ── Requests (30 requests) ───────────────────────────────────
-- 20 Accepted (→ Trips), 5 Pending, 5 Rejected
INSERT INTO Request (RequestTime, PickupLocation, DropoffLocation, Status, RiderID) VALUES
    ('2024-11-01 09:00:00', 'Maadi, Cairo',          'Zamalek, Cairo',        'Accepted',  1),   -- 1
    ('2024-11-01 11:30:00', 'Heliopolis, Cairo',     'Nasr City, Cairo',      'Accepted',  2),   -- 2
    ('2024-11-02 14:00:00', 'Giza, Cairo',           'Downtown Cairo',        'Accepted',  3),   -- 3
    ('2024-11-03 10:00:00', 'Dokki, Giza',           '6th October City',      'Accepted',  4),   -- 4
    ('2024-11-04 08:00:00', 'New Cairo',             'Cairo Airport',         'Accepted',  5),   -- 5
    ('2024-11-04 13:00:00', 'Mohandessin, Giza',     'Zamalek, Cairo',        'Accepted',  6),   -- 6
    ('2024-11-05 09:30:00', 'Nasr City, Cairo',      'Maadi, Cairo',          'Accepted',  7),   -- 7
    ('2024-11-05 16:00:00', 'Zamalek, Cairo',        'Heliopolis, Cairo',     'Accepted',  8),   -- 8
    ('2024-11-06 07:45:00', 'Shubra, Cairo',         'Dokki, Giza',           'Accepted',  9),   -- 9
    ('2024-11-06 12:30:00', 'Downtown Cairo',        'New Cairo',             'Accepted',  10),  -- 10
    ('2024-11-07 10:00:00', '6th October City',      'Giza, Cairo',           'Accepted',  11),  -- 11
    ('2024-11-07 14:30:00', 'Cairo Airport',         'Nasr City, Cairo',      'Accepted',  12),  -- 12
    ('2024-11-08 08:00:00', 'Maadi, Cairo',          'Mohandessin, Giza',     'Accepted',  13),  -- 13
    ('2024-11-08 11:00:00', 'Heliopolis, Cairo',     'Downtown Cairo',        'Accepted',  14),  -- 14
    ('2024-11-09 09:15:00', 'New Cairo',             'Zamalek, Cairo',        'Accepted',  15),  -- 15
    ('2024-11-09 15:00:00', 'Dokki, Giza',           'Cairo Airport',         'Accepted',  16),  -- 16
    ('2024-11-10 10:45:00', 'Nasr City, Cairo',      'Shubra, Cairo',         'Accepted',  17),  -- 17
    ('2024-11-10 13:30:00', 'Giza, Cairo',           'Heliopolis, Cairo',     'Accepted',  20),  -- 18
    ('2024-11-11 08:30:00', 'Zamalek, Cairo',        'New Cairo',             'Accepted',  1),   -- 19
    ('2024-11-11 17:00:00', 'Mohandessin, Giza',     'Maadi, Cairo',          'Accepted',  2),   -- 20
    ('2024-11-12 09:00:00', 'Shubra, Cairo',         'Downtown Cairo',        'Pending',   3),   -- 21
    ('2024-11-12 10:00:00', 'New Cairo',             'Cairo Airport',         'Pending',   4),   -- 22
    ('2024-11-12 11:00:00', 'Maadi, Cairo',          'Nasr City, Cairo',      'Pending',   5),   -- 23
    ('2024-11-12 12:00:00', 'Heliopolis, Cairo',     '6th October City',      'Pending',   6),   -- 24
    ('2024-11-12 13:00:00', 'Dokki, Giza',           'Zamalek, Cairo',        'Pending',   7),   -- 25
    ('2024-11-12 09:30:00', 'Giza, Cairo',           'Mohandessin, Giza',     'Rejected',  8),   -- 26
    ('2024-11-12 10:30:00', 'Cairo Airport',         'Maadi, Cairo',          'Rejected',  9),   -- 27
    ('2024-11-12 11:30:00', 'Downtown Cairo',        'Heliopolis, Cairo',     'Rejected',  10),  -- 28
    ('2024-11-12 12:30:00', 'Nasr City, Cairo',      'New Cairo',             'Rejected',  11),  -- 29
    ('2024-11-12 13:30:00', '6th October City',      'Shubra, Cairo',         'Rejected',  12);  -- 30

-- ── Trips (20 trips for the 20 Accepted requests) ────────────
-- 17 Completed, 3 Ongoing
INSERT INTO Trip (StartLocation, EndLocation, StartTime, EndTime, Status, RequestID, DriverID) VALUES
    ('Maadi, Cairo',          'Zamalek, Cairo',        '2024-11-01 09:05:00', '2024-11-01 09:50:00', 'Completed', 1,  1),   -- TripID 1
    ('Heliopolis, Cairo',     'Nasr City, Cairo',      '2024-11-01 11:35:00', '2024-11-01 12:05:00', 'Completed', 2,  2),   -- TripID 2
    ('Giza, Cairo',           'Downtown Cairo',        '2024-11-02 14:10:00', '2024-11-02 15:00:00', 'Completed', 3,  3),   -- TripID 3
    ('Dokki, Giza',           '6th October City',      '2024-11-03 10:05:00', '2024-11-03 11:10:00', 'Completed', 4,  4),   -- TripID 4
    ('New Cairo',             'Cairo Airport',         '2024-11-04 08:10:00', '2024-11-04 09:00:00', 'Completed', 5,  5),   -- TripID 5
    ('Mohandessin, Giza',     'Zamalek, Cairo',        '2024-11-04 13:05:00', '2024-11-04 13:40:00', 'Completed', 6,  6),   -- TripID 6
    ('Nasr City, Cairo',      'Maadi, Cairo',          '2024-11-05 09:35:00', '2024-11-05 10:25:00', 'Completed', 7,  7),   -- TripID 7
    ('Zamalek, Cairo',        'Heliopolis, Cairo',     '2024-11-05 16:05:00', '2024-11-05 16:55:00', 'Completed', 8,  8),   -- TripID 8
    ('Shubra, Cairo',         'Dokki, Giza',           '2024-11-06 07:50:00', '2024-11-06 08:45:00', 'Completed', 9,  9),   -- TripID 9
    ('Downtown Cairo',        'New Cairo',             '2024-11-06 12:35:00', '2024-11-06 13:30:00', 'Completed', 10, 10),  -- TripID 10
    ('6th October City',      'Giza, Cairo',           '2024-11-07 10:05:00', '2024-11-07 11:00:00', 'Completed', 11, 11),  -- TripID 11
    ('Cairo Airport',         'Nasr City, Cairo',      '2024-11-07 14:35:00', '2024-11-07 15:25:00', 'Completed', 12, 12),  -- TripID 12
    ('Maadi, Cairo',          'Mohandessin, Giza',     '2024-11-08 08:05:00', '2024-11-08 09:00:00', 'Completed', 13, 13),  -- TripID 13
    ('Heliopolis, Cairo',     'Downtown Cairo',        '2024-11-08 11:05:00', '2024-11-08 11:50:00', 'Completed', 14, 14),  -- TripID 14
    ('New Cairo',             'Zamalek, Cairo',        '2024-11-09 09:20:00', '2024-11-09 10:20:00', 'Completed', 15, 16),  -- TripID 15
    ('Dokki, Giza',           'Cairo Airport',         '2024-11-09 15:05:00', '2024-11-09 16:05:00', 'Completed', 16, 19),  -- TripID 16
    ('Nasr City, Cairo',      'Shubra, Cairo',         '2024-11-10 10:50:00', '2024-11-10 11:35:00', 'Completed', 17, 20),  -- TripID 17
    ('Giza, Cairo',           'Heliopolis, Cairo',     '2024-11-10 13:35:00', NULL,                   'Ongoing',   18, 15),  -- TripID 18
    ('Zamalek, Cairo',        'New Cairo',             '2024-11-11 08:35:00', NULL,                   'Ongoing',   19, 17),  -- TripID 19
    ('Mohandessin, Giza',     'Maadi, Cairo',          '2024-11-11 17:05:00', NULL,                   'Ongoing',   20, 18);  -- TripID 20

-- ── Payments (20 payments: 17 Paid for completed trips, 3 Pending for ongoing) ──
INSERT INTO Payment (Amount, PaymentMethod, PaymentStatus, PaymentDate, TripID) VALUES
    (55.00,  'Card',   'Paid',    '2024-11-01 09:50:00', 1),
    (30.00,  'Wallet', 'Paid',    '2024-11-01 12:05:00', 2),
    (45.00,  'Cash',   'Paid',    '2024-11-02 15:00:00', 3),
    (70.00,  'Cash',   'Paid',    '2024-11-03 11:10:00', 4),
    (80.00,  'Card',   'Paid',    '2024-11-04 09:00:00', 5),
    (40.00,  'Card',   'Paid',    '2024-11-04 13:40:00', 6),
    (60.00,  'Wallet', 'Paid',    '2024-11-05 10:25:00', 7),
    (50.00,  'Card',   'Paid',    '2024-11-05 16:55:00', 8),
    (65.00,  'Cash',   'Paid',    '2024-11-06 08:45:00', 9),
    (75.00,  'Cash',   'Paid',    '2024-11-06 13:30:00', 10),
    (85.00,  'Wallet', 'Paid',    '2024-11-07 11:00:00', 11),
    (55.00,  'Card',   'Paid',    '2024-11-07 15:25:00', 12),
    (60.00,  'Cash',   'Paid',    '2024-11-08 09:00:00', 13),
    (45.00,  'Wallet', 'Paid',    '2024-11-08 11:50:00', 14),
    (90.00,  'Card',   'Paid',    '2024-11-09 10:20:00', 15),
    (95.00,  'Wallet', 'Paid',    '2024-11-09 16:05:00', 16),
    (50.00,  'Card',   'Paid',    '2024-11-10 11:35:00', 17),
    (70.00,  'Cash',   'Pending', NULL,                   18),
    (85.00,  'Card',   'Pending', NULL,                   19),
    (55.00,  'Wallet', 'Pending', NULL,                   20);

-- ── TripFeedback (Weak Entity — 30 feedback records across 17 completed trips) ──
INSERT INTO TripFeedback (TripID, FeedbackID, Rating, Comment) VALUES
    (1,  1, 5, 'Great driver, very punctual!'),
    (1,  2, 4, 'Smooth ride, clean car.'),
    (2,  1, 3, 'A bit slow but okay.'),
    (3,  1, 5, 'Excellent service!'),
    (3,  2, 5, 'Very professional driver.'),
    (4,  1, 4, 'Good ride, comfortable.'),
    (5,  1, 5, 'Arrived on time to the airport.'),
    (5,  2, 4, 'Friendly and helpful.'),
    (6,  1, 3, 'Route was a bit long.'),
    (7,  1, 4, 'Pleasant experience overall.'),
    (7,  2, 5, 'Driver was very polite.'),
    (8,  1, 2, 'Car smelled bad.'),
    (8,  2, 3, 'Okay but nothing special.'),
    (9,  1, 5, 'Amazing driver, will use again.'),
    (10, 1, 4, 'Comfortable and on time.'),
    (10, 2, 4, 'Good experience.'),
    (11, 1, 1, 'Driver was rude and late.'),
    (12, 1, 5, 'Perfect ride to the airport!'),
    (12, 2, 5, 'Highly recommend this driver.'),
    (13, 1, 3, 'Average ride.'),
    (14, 1, 4, 'Good driver, fast route.'),
    (14, 2, 5, 'Very clean car.'),
    (15, 1, 5, 'Wonderful experience.'),
    (15, 2, 4, 'Would definitely ride again.'),
    (16, 1, 2, 'Late pickup, poor communication.'),
    (16, 2, 3, 'Ride was okay but driver was quiet.'),
    (17, 1, 4, 'Smooth and quick ride.'),
    (17, 2, 5, 'Driver knew all the shortcuts.'),
    (17, 3, 4, 'Very satisfied.'),
    (6,  2, 4, 'Good value for money.');