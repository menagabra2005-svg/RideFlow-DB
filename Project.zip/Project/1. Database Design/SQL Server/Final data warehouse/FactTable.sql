USE RideHailingDW;
GO

INSERT INTO FactTrip (

    TripID,
    DateKey,
    RiderKey,
    DriverKey,

    PickupLocationKey,
    DropoffLocationKey,

    RequestStatus,
    TripStatus,

    PaymentStatus,
    PaymentMethod,

    TripDurationMinutes,

    Amount,

    FeedbackRating
)

SELECT

    t.TripID,

    CONVERT(INT, FORMAT(t.StartTime, 'yyyyMMdd')),

    dr.RiderKey,

    dd.DriverKey,

    pl.LocationKey,

    dl.LocationKey,

    req.Status,

    t.Status,

    p.PaymentStatus,

    p.PaymentMethod,

    DATEDIFF(MINUTE, t.StartTime, t.EndTime),

    p.Amount,

    AVG(CAST(tf.Rating AS FLOAT))

FROM RideHailingDB.dbo.Trip t

JOIN RideHailingDB.dbo.Request req
    ON t.RequestID = req.RequestID

JOIN DimRider dr
    ON req.RiderID = dr.UserID

JOIN DimDriver dd
    ON t.DriverID = dd.DriverID

JOIN DimLocation pl
    ON t.StartLocation = pl.LocationName

JOIN DimLocation dl
    ON t.EndLocation = dl.LocationName

LEFT JOIN RideHailingDB.dbo.Payment p
    ON t.TripID = p.TripID

LEFT JOIN RideHailingDB.dbo.TripFeedback tf
    ON t.TripID = tf.TripID

GROUP BY

    t.TripID,

    t.StartTime,

    dr.RiderKey,

    dd.DriverKey,

    pl.LocationKey,

    dl.LocationKey,

    req.Status,

    t.Status,

    p.PaymentStatus,

    p.PaymentMethod,

    p.Amount,

    t.EndTime;
GO

SELECT * FROM FactTrip;

-- ============================================================
-- EXPAND FACT TABLE DATA
-- Generate Additional Analytical Records
-- ============================================================

INSERT INTO FactTrip (

    TripID,
    DateKey,
    RiderKey,
    DriverKey,

    PickupLocationKey,
    DropoffLocationKey,

    RequestStatus,
    TripStatus,

    PaymentStatus,
    PaymentMethod,

    TripDurationMinutes,

    Amount,

    FeedbackRating
)

SELECT

    TripID + 1000,
    DateKey + 1,
    RiderKey,
    DriverKey,

    PickupLocationKey,
    DropoffLocationKey,

    RequestStatus,
    TripStatus,

    PaymentStatus,
    PaymentMethod,

    TripDurationMinutes + 5,

    Amount + 10,

    FeedbackRating

FROM FactTrip;


INSERT INTO FactTrip (

    TripID,
    DateKey,
    RiderKey,
    DriverKey,

    PickupLocationKey,
    DropoffLocationKey,

    RequestStatus,
    TripStatus,

    PaymentStatus,
    PaymentMethod,

    TripDurationMinutes,

    Amount,

    FeedbackRating
)

SELECT

    TripID + 2000,
    DateKey + 2,
    RiderKey,
    DriverKey,

    PickupLocationKey,
    DropoffLocationKey,

    RequestStatus,
    TripStatus,

    PaymentStatus,
    PaymentMethod,

    TripDurationMinutes + 10,

    Amount + 20,

    FeedbackRating

FROM FactTrip
WHERE TripID < 1000;


GO

SELECT * FROM FactTrip;