-- =====================================================
-- CREATE DATA WAREHOUSE DATABASE
-- =====================================================

USE master;
GO

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'RideHailingDW')
BEGIN
    ALTER DATABASE RideHailingDW
    SET SINGLE_USER WITH ROLLBACK IMMEDIATE;

    DROP DATABASE RideHailingDW;
END
GO

CREATE DATABASE RideHailingDW;
GO

USE RideHailingDW;
GO

-- =====================================================
-- DIM DATE
-- =====================================================

CREATE TABLE DimDate (
    DateKey INT PRIMARY KEY,
    FullDate DATE,
    DayNumber INT,
    MonthNumber INT,
    MonthName NVARCHAR(20),
    QuarterNumber INT,
    YearNumber INT
);
GO

-- =====================================================
-- DIM RIDER
-- =====================================================

CREATE TABLE DimRider (
    RiderKey INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT,
    RiderName NVARCHAR(100),
    Email NVARCHAR(150),
    Age INT,
    PreferredPaymentMethod NVARCHAR(50),
    RiderRating FLOAT,
    TotalReviews INT
);
GO

-- =====================================================
-- DIM DRIVER
-- =====================================================

CREATE TABLE DimDriver (
    DriverKey INT IDENTITY(1,1) PRIMARY KEY,
    DriverID INT,
    DriverName NVARCHAR(100),
    LicenseNumber NVARCHAR(50),
    DriverType NVARCHAR(20),
    DriverStatus NVARCHAR(20),
    DriverRating FLOAT,
    TotalReviews INT
);
GO

-- =====================================================
-- DIM LOCATION
-- =====================================================

CREATE TABLE DimLocation (
    LocationKey INT IDENTITY(1,1) PRIMARY KEY,
    LocationName NVARCHAR(255)
);
GO

-- =====================================================
-- FACT TRIP
-- =====================================================

CREATE TABLE FactTrip (
    TripFactKey INT IDENTITY(1,1) PRIMARY KEY,

    TripID INT,

    DateKey INT,
    RiderKey INT,
    DriverKey INT,

    PickupLocationKey INT,
    DropoffLocationKey INT,

    RequestStatus NVARCHAR(20),
    TripStatus NVARCHAR(20),

    PaymentStatus NVARCHAR(20),
    PaymentMethod NVARCHAR(20),

    TripDurationMinutes INT,

    Amount DECIMAL(10,2),

    FeedbackRating FLOAT,

    FOREIGN KEY (DateKey)
        REFERENCES DimDate(DateKey),

    FOREIGN KEY (RiderKey)
        REFERENCES DimRider(RiderKey),

    FOREIGN KEY (DriverKey)
        REFERENCES DimDriver(DriverKey),

    FOREIGN KEY (PickupLocationKey)
        REFERENCES DimLocation(LocationKey),

    FOREIGN KEY (DropoffLocationKey)
        REFERENCES DimLocation(LocationKey)
);
GO