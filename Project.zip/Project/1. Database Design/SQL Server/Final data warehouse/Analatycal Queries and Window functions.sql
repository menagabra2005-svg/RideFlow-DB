USE RideHailingDw;
GO

-- ========TOP DRIVERS===========
SELECT TOP 5
    d.DriverName,
    AVG(f.Amount) AS AvgRevenue,
    AVG(f.FeedbackRating) AS AvgRating
FROM FactTrip f
JOIN DimDriver d
    ON f.DriverKey = d.DriverKey
GROUP BY d.DriverName
ORDER BY AvgRevenue DESC;

-- =========REVENUE BY PAYMENT METHOD=========================
SELECT
    PaymentMethod,
    SUM(Amount) AS TotalRevenue
FROM FactTrip
GROUP BY PaymentMethod;

-- =======MOST POPULAR LOCATIONS=============
SELECT
    l.LocationName,
    COUNT(*) AS TotalTrips
FROM FactTrip f
JOIN DimLocation l
    ON f.PickupLocationKey = l.LocationKey
GROUP BY l.LocationName
ORDER BY TotalTrips DESC;

-- =======REVENUE BY DRIVER TYPE==========
SELECT
    d.DriverType,
    COUNT(*) AS TotalTrips,
    AVG(f.Amount) AS AvgRevenue
FROM FactTrip f
JOIN DimDriver d
    ON f.DriverKey = d.DriverKey
GROUP BY d.DriverType;

--======== MONTHLY REVENUE=========
SELECT
    d.MonthName,
    SUM(f.Amount) AS TotalRevenue
FROM FactTrip f
JOIN DimDate d
    ON f.DateKey = d.DateKey
GROUP BY d.MonthName;

--========AVG & TOTAL REVENUE BY DRIVER TYPE & PAYMENT===========
SELECT
    d.DriverType,
    f.PaymentMethod,
    COUNT(*) AS TotalTrips,
    AVG(f.Amount) AS AvgRevenue,
    SUM(f.Amount) AS TotalRevenue

FROM FactTrip f
JOIN DimDriver d
    ON f.DriverKey = d.DriverKey

GROUP BY
    d.DriverType,
    f.PaymentMethod;


-- ===== Window functions==========

-- ============================================================
-- WINDOW FUNCTIONS ANALYSIS
-- ============================================================

-- ============================================================
-- 1. Rank Drivers by Average Rating
-- Purpose:
-- Shows the best drivers based on customer feedback.
-- ============================================================

SELECT
    d.DriverKey,
    d.DriverName,

    ROUND(AVG(CAST(ft.FeedbackRating AS FLOAT)), 2) AS AvgRating,

    RANK() OVER (
        ORDER BY 
            AVG(CAST(ft.FeedbackRating AS FLOAT)) DESC 
    ) AS DriverRank

FROM DimDriver d
LEFT JOIN FactTrip ft
    ON d.DriverKey = ft.DriverKey

GROUP BY d.DriverKey, d.DriverName;

--- ========================
-- ============================================================
-- 2. Dense Rank Drivers by Rating
-- Purpose:
-- Rank drivers without skipping numbers after ties.
-- ============================================================

SELECT
    d.DriverKey,
    d.DriverName,

    ROUND(AVG(CAST(ft.FeedbackRating AS FLOAT)), 2) AS AvgRating,

    DENSE_RANK() OVER (
        ORDER BY 
            AVG(CAST(ft.FeedbackRating AS FLOAT)) DESC 
    ) AS DenseDriverRank

FROM DimDriver d
LEFT JOIN FactTrip ft
    ON d.DriverKey = ft.DriverKey

GROUP BY d.DriverKey, d.DriverName;
-- ======================
-- ============================================================
-- 3. Running Total of Revenue
-- Purpose:
-- Shows cumulative company revenue over time.
-- ============================================================

SELECT
    ft.DateKey,
    dd.FullDate,   -- optional if DimDate exists
    ft.Amount,

    SUM(ft.Amount) OVER (
        ORDER BY ft.DateKey
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS RunningRevenue

FROM FactTrip ft
LEFT JOIN DimDate dd
    ON ft.DateKey = dd.DateKey

WHERE ft.Amount IS NOT NULL;

-- ============================================================
-- 4. Ranking by Revenue and Driver type
-- Purpose:
-- Shows Ranking of the driver based on their type and average revenue
-- ============================================================

SELECT
    d.DriverName,
    d.DriverType,
    AVG(ft.Amount) AS AvgRevenue,

    RANK() OVER (
        PARTITION BY d.DriverType
        ORDER BY AVG(ft.Amount) DESC
    ) AS RevenueRank

FROM FactTrip ft
JOIN DimDriver d
    ON ft.DriverKey = d.DriverKey

GROUP BY
    d.DriverName,
    d.DriverType;