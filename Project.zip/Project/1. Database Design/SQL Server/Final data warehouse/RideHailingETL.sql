USE RideHailingDW;
GO

-- =====================================================
-- LOAD DIM DATE
-- =====================================================

DECLARE @StartDate DATE = '2024-11-01';
DECLARE @EndDate DATE = '2024-12-31';

WHILE @StartDate <= @EndDate
BEGIN

    INSERT INTO DimDate
    VALUES (
        CONVERT(INT, FORMAT(@StartDate, 'yyyyMMdd')),
        @StartDate,
        DAY(@StartDate),
        MONTH(@StartDate),
        DATENAME(MONTH, @StartDate),
        DATEPART(QUARTER, @StartDate),
        YEAR(@StartDate)
    );

    SET @StartDate = DATEADD(DAY, 1, @StartDate);

END;
GO

-- =====================================================
-- LOAD DIM RIDER
-- =====================================================

INSERT INTO DimRider (
    UserID,
    RiderName,
    Email,
    Age,
    PreferredPaymentMethod,
    RiderRating,
    TotalReviews
)

SELECT
    r.UserID,
    u.Name,
    u.Email,
    ua.Age,
    r.PreferredPaymentMethod,
    rr.Rating,
    rr.TotalReviews

FROM RideHailingDB.dbo.Rider r

JOIN RideHailingDB.dbo.[User] u
    ON r.UserID = u.UserID

LEFT JOIN RideHailingDB.dbo.vw_UserWithAge ua
    ON ua.UserID = u.UserID

LEFT JOIN RideHailingDB.dbo.vw_RiderRating rr
    ON rr.UserID = r.UserID;
GO

-- =====================================================
-- LOAD DIM DRIVER
-- =====================================================

INSERT INTO DimDriver (
    DriverID,
    DriverName,
    LicenseNumber,
    DriverType,
    DriverStatus,
    DriverRating,
    TotalReviews
)

SELECT
    d.DriverID,
    d.Name,
    d.LicenseNumber,

    CASE
        WHEN ft.DriverID IS NOT NULL THEN 'Full-Time'
        WHEN pt.DriverID IS NOT NULL THEN 'Part-Time'
    END,

    d.Status,

    vr.Rating,
    vr.TotalReviews

FROM RideHailingDB.dbo.Driver d

LEFT JOIN RideHailingDB.dbo.FullTimeDriver ft
    ON d.DriverID = ft.DriverID

LEFT JOIN RideHailingDB.dbo.PartTimeDriver pt
    ON d.DriverID = pt.DriverID

LEFT JOIN RideHailingDB.dbo.vw_DriverRating vr
    ON d.DriverID = vr.DriverID;
GO

-- =====================================================
-- LOAD DIM LOCATION
-- =====================================================

INSERT INTO DimLocation (LocationName)

SELECT DISTINCT PickupLocation
FROM RideHailingDB.dbo.Request

UNION

SELECT DISTINCT DropoffLocation
FROM RideHailingDB.dbo.Request;
GO

SELECT * FROM DimRider;
SELECT * FROM DimDriver;
SELECT * FROM DimLocation;