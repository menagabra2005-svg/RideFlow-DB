-- ============================================================
--  RIDE-HAILING SYSTEM — TRANSACTIONS
--  Database: RideHailingDB
--  Section 2 — Core Implementation
-- ============================================================

USE RideHailingDB;
GO


-- ── TX1: Register a New Rider ─────────────────────────────────
-- Atomically inserts into User (supertype), Rider (subtype),
-- and UserPhone (multi-valued attribute).
-- Rolls back if email is duplicate or payment method is invalid.
-- Note: 'layla@mail.com' is taken by UserID 5 (Layla Ibrahim);
--       using a unique email here.

EXEC sp_RegisterRider
    @Name                   = 'Layla Ahmed',
    @Email                  = 'layla.ahmed@mail.com',
    @DOB                    = '2001-05-10',
    @Phone                  = '+20-100-555-1234',
    @PreferredPaymentMethod = 'Card';
GO
-- Result: NewRiderID = 21 (next UserID after seed data)

-- ── Failure test — duplicate email ───────────────────────────
-- Uncomment to verify rollback behavior:
-- EXEC sp_RegisterRider
--     @Name  = 'Duplicate Test',
--     @Email = 'ahmed@mail.com',   -- already exists (UserID 1) → ROLLBACK
--     @DOB   = '1999-01-01',
--     @Phone = '+20-100-000-0000';
-- GO


-- ── TX2: Register a New Full-Time Driver ─────────────────────
-- Atomically inserts into Driver (supertype), FullTimeDriver (subtype),
-- and DriverPhone (multi-valued attribute).
-- Rolls back if license is duplicate or salary is <= 0.
-- Note: LIC-001 through LIC-020 are taken by seed data;
--       using LIC-021 here.

EXEC sp_RegisterFullTimeDriver
    @Name          = 'Youssef Tamer',
    @LicenseNumber = 'LIC-021',
    @Phone         = '+20-100-777-5555',
    @Salary        = 9000.00;
GO
-- Result: NewDriverID = 21 (next DriverID after seed data)

-- ── Failure test — invalid salary ────────────────────────────
-- Uncomment to verify rollback behavior:
-- EXEC sp_RegisterFullTimeDriver
--     @Name          = 'Bad Salary Driver',
--     @LicenseNumber = 'LIC-999',
--     @Phone         = '+20-100-000-9999',
--     @Salary        = 0;   -- violates CHK_FTDriver_Salary → ROLLBACK
-- GO


-- ── TX3: Register a New Part-Time Driver ─────────────────────
-- Atomically inserts into Driver and PartTimeDriver.
-- WorkingHours is optional (nullable).
-- Note: LIC-001 through LIC-021 are now taken;
--       using LIC-022 here.

EXEC sp_RegisterPartTimeDriver
    @Name          = 'Amira Samy',
    @LicenseNumber = 'LIC-022',
    @Phone         = '+20-111-888-6666',
    @WorkingHours  = 'Sat-Thu 8AM-2PM';
GO
-- Result: NewDriverID = 22


-- ── TX4: Create a Ride Request ───────────────────────────────
-- No transaction needed (single INSERT).
-- Validates that the RiderID exists before inserting.
-- RiderID 4 = Nour Eldin (exists in Rider table).

EXEC sp_CreateRequest
    @RiderID         = 4,
    @PickupLocation  = 'New Cairo',
    @DropoffLocation = 'Cairo Airport';
GO
-- Result: NewRequestID = 31 (next RequestID after 30 seed requests)

-- ── Failure test — non-existent rider ────────────────────────
-- Uncomment to verify validation:
-- EXEC sp_CreateRequest
--     @RiderID         = 999,   -- does not exist → RAISERROR
--     @PickupLocation  = 'Anywhere',
--     @DropoffLocation = 'Nowhere';
-- GO


-- ── TX5: Accept Request → Create Trip ────────────────────────
-- Critical 4-step transaction:
--   1. Validates Request is Pending
--   2. Validates Driver is Available
--   3. UPDATE Request  SET Status = 'Accepted'
--   4. INSERT INTO Trip
--   5. UPDATE Driver   SET Status = 'Busy'
-- All 5 steps succeed or all roll back.
--
-- Using RequestID 31 (just created above, Status = 'Pending')
-- and DriverID 1 = Karim Samir (Status = 'Available' in seed data).

EXEC sp_AcceptRequest
    @RequestID = 31,
    @DriverID  = 1;
GO
-- Side effects after commit:
--   Request 31 → Status = 'Accepted'
--   Trip 21    → inserted (Status = 'Ongoing')
--   Driver 1   → Status = 'Busy'

-- ── Failure test — driver already busy ───────────────────────
-- Uncomment to verify rollback behavior:
-- EXEC sp_AcceptRequest
--     @RequestID = 32,
--     @DriverID  = 6;   -- Amr Gaber (DriverID 6) is Busy → RAISERROR + ROLLBACK
-- GO


-- ── TX6: Complete Trip and Record Payment ────────────────────
-- 3-step transaction:
--   1. Validates Trip is Ongoing
--   2. UPDATE Trip    SET Status = 'Completed', EndTime = GETDATE()
--   3. INSERT INTO Payment
--   4. UPDATE Driver  SET Status = 'Available'
-- Atomicity guarantees driver is never stuck as 'Busy'
-- if payment insertion fails.
--
-- Using TripID 18 (Status = 'Ongoing', DriverID = 15 = Samir Badawi).
-- Trips 1–17 are already 'Completed' in seed data.

EXEC sp_CompleteTrip
    @TripID        = 18,
    @Amount        = 45.00,
    @PaymentMethod = 'Cash';
GO
-- Side effects after commit:
--   Trip 18    → Status = 'Completed', EndTime = NOW()
--   Payment 18 → Status updated to 'Paid', PaymentDate = NOW(), Amount = 45.00
--   Driver 15  → Status = 'Available'

-- ── Failure test — already completed trip ────────────────────
-- Uncomment to verify rollback behavior:
-- EXEC sp_CompleteTrip
--     @TripID        = 1,   -- already 'Completed' → RAISERROR + ROLLBACK
--     @Amount        = 99.00,
--     @PaymentMethod = 'Card';
-- GO


-- ── TX7: Submit Feedback for a Trip ──────────────────────────
-- Not wrapped in BEGIN/COMMIT (single INSERT) but includes
-- validation that the trip is Completed before accepting feedback.
-- FeedbackID is auto-incremented as a partial key within the trip.
--
-- Using TripID 18 (just completed above in TX6).
-- Alternatively, any of TripIDs 1–17 already have feedback in seed data
-- and can accept additional entries since TripFeedback is a weak entity.

EXEC sp_SubmitFeedback
    @TripID  = 18,
    @Rating  = 4,
    @Comment = 'Good driver, arrived quickly.';
GO

-- Submit a second feedback on the same trip (weak entity allows it)
EXEC sp_SubmitFeedback
    @TripID  = 18,
    @Rating  = 5,
    @Comment = 'Very clean car!';
GO

-- ── Failure test — feedback on ongoing trip ───────────────────
-- Uncomment to verify validation:
-- EXEC sp_SubmitFeedback
--     @TripID = 19,    -- Trip 19 is Ongoing → RAISERROR
--     @Rating = 5,
--     @Comment = 'This should not work.';
-- GO


-- ============================================================
--  VERIFY FINAL STATE
-- ============================================================

-- All trips and their current status
SELECT TripID, StartLocation, EndLocation, Status, StartTime, EndTime
FROM   Trip
ORDER  BY TripID;
GO

-- All drivers and their current availability
SELECT DriverID, Name, Status
FROM   Driver
ORDER  BY DriverID;
GO

-- All payments recorded
SELECT PaymentID, TripID, Amount, PaymentMethod, PaymentStatus, PaymentDate
FROM   Payment
ORDER  BY PaymentID;
GO

-- All feedback submitted
SELECT TripID, FeedbackID, Rating, Comment
FROM   TripFeedback
ORDER  BY TripID, FeedbackID;
GO


-- ============================================================
--  END OF TRANSACTIONS
-- ============================================================