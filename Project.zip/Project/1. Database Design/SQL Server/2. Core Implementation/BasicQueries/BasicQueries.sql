-- ============================================================
--  RIDE-HAILING SYSTEM — BASIC QUERIES
--  Database: RideHailingDB
--  Section 2 — Core Implementation
-- ============================================================

USE RideHailingDB;
GO


-- ── Q1: All Riders with Derived Age ──────────────────────────
-- Age is a derived attribute computed via vw_UserWithAge (DATEDIFF on DOB).
-- Not stored to avoid update anomalies.

SELECT u.UserID,
       u.Name,
       u.Email,
       u.DOB,
       u.Age
FROM   vw_UserWithAge u
WHERE  u.UserID IN (SELECT UserID FROM Rider);
GO


-- ── Q2: All Drivers with Type and Rating ─────────────────────
-- Driver subtype (Full-Time / Part-Time) determined via LEFT JOIN.
-- Rating is derived from TripFeedback via vw_DriverRating.

SELECT vr.DriverID,
       vr.Name,
       vr.Status,
       CASE
           WHEN ft.DriverID IS NOT NULL THEN 'Full-Time'
           WHEN pt.DriverID IS NOT NULL THEN 'Part-Time'
       END                  AS DriverType,
       ISNULL(vr.Rating, 0) AS Rating,
       vr.TotalReviews
FROM   vw_DriverRating   vr
LEFT JOIN FullTimeDriver ft ON ft.DriverID = vr.DriverID
LEFT JOIN PartTimeDriver pt ON pt.DriverID = vr.DriverID;
GO


-- ── Q3: Full Trip Details via View ───────────────────────────
-- vw_TripDetails joins 7 tables: Trip, Request, Rider, User,
-- Driver, Payment, TripFeedback.

SELECT TripID,
       StartLocation,
       EndLocation,
       TripStatus,
       DurationMinutes,
       RiderName,
       RiderEmail,
       DriverName,
       LicenseNumber,
       Amount,
       PaymentMethod,
       PaymentStatus,
       AvgFeedbackRating
FROM   vw_TripDetails
ORDER  BY TripID;
GO


-- ── Q4: Total Revenue per Payment Method ─────────────────────
-- Aggregates only PAID transactions.
-- Useful for financial reporting by channel.

SELECT PaymentMethod,
       COUNT(*)    AS TotalTransactions,
       SUM(Amount) AS TotalRevenue,
       AVG(Amount) AS AvgFare
FROM   Payment
WHERE  PaymentStatus = 'Paid'
GROUP  BY PaymentMethod;
GO


-- ── Q5: Top-Rated Drivers ────────────────────────────────────
-- Returns top 5 drivers who have at least one review,
-- ranked by average rating then total reviews (tiebreaker).

SELECT TOP 5
       DriverID,
       Name,
       Rating,
       TotalReviews
FROM   vw_DriverRating
WHERE  TotalReviews > 0
ORDER  BY Rating DESC, TotalReviews DESC;
GO


-- ── Q6: Trips with Feedback Summary ─────────────────────────
-- LEFT JOIN ensures trips with zero feedback still appear.
-- FeedbackID is the partial key of the TripFeedback weak entity.

SELECT t.TripID,
       t.StartLocation,
       t.EndLocation,
       t.Status,
       COUNT(tf.FeedbackID)          AS FeedbackCount,
       AVG(CAST(tf.Rating AS FLOAT)) AS AvgRating
FROM   Trip t
LEFT JOIN TripFeedback tf ON tf.TripID = t.TripID
GROUP  BY t.TripID, t.StartLocation, t.EndLocation, t.Status;
GO


-- ── Q7: Rider Trip History (Stored Procedure) ────────────────
-- Returns full history for a given rider, most recent first.
-- Includes driver info, payment, and average feedback rating.

EXEC sp_GetRiderHistory @RiderID = 1;
GO


-- ── Q8: Available Drivers (Stored Procedure) ─────────────────
-- Returns all drivers with Status = 'Available'.
-- Phone numbers concatenated via STRING_AGG.

EXEC sp_GetAvailableDrivers;
GO


-- ── Q9: Monthly Revenue Report ──────────────────────────────
-- Groups paid payments by year and month.
-- Useful for identifying seasonal demand patterns.

SELECT YEAR(PaymentDate)  AS [Year],
       MONTH(PaymentDate) AS [Month],
       COUNT(*)           AS TotalTrips,
       SUM(Amount)        AS TotalRevenue
FROM   Payment
WHERE  PaymentStatus = 'Paid'
GROUP  BY YEAR(PaymentDate), MONTH(PaymentDate)
ORDER  BY [Year], [Month];
GO


-- ============================================================
--  END OF BASIC QUERIES
-- ============================================================
