-- ============================================
-- Advanced Database Project
-- Concurrency and Recovery
-- SQL Server Implementation — RideHailingDB
-- ============================================

USE RideHailingDB;
GO

-- ============================================
-- 1. CONCURRENCY
-- ============================================
-- Scenario:
--   Two dispatchers try to assign Driver 15
--   to different trips at the same time.
--   Session 1 marks Trip 18 as 'Completed'.
--   Session 2 tries to cancel that same trip.
--   SQL Server's row-level locking forces
--   Session 2 to wait until Session 1 commits.
-- ============================================

-- Open TWO query windows in SSMS.
-- Run Session 1 first, then immediately run Session 2.

-- ============================================
-- SESSION 1
-- ============================================

BEGIN TRANSACTION;

-- Dispatcher 1 completes Trip 18 (currently Ongoing, driven by Driver 15)
UPDATE Trip
SET Status  = 'Completed',
    EndTime = '2024-11-10 14:30:00'
WHERE TripID = 18;

-- Hold the exclusive lock for 20 seconds
-- (simulates dispatcher reviewing the record before committing)
WAITFOR DELAY '00:00:20';

COMMIT TRANSACTION;

-- ============================================
-- SESSION 2
-- ============================================

BEGIN TRANSACTION;

-- Dispatcher 2 tries to cancel the same trip simultaneously
-- This will BLOCK until Session 1 releases its lock
UPDATE Trip
SET Status = 'Cancelled'
WHERE TripID = 18;

COMMIT TRANSACTION;

-- ============================================
-- Explanation:
--   Session 1 acquires an exclusive (X) lock on
--   Trip row 18. Session 2 cannot modify the same
--   row until Session 1 commits and releases the lock.
--   This demonstrates SQL Server's automatic
--   row-level locking for concurrency control,
--   preventing lost updates and dirty reads.
-- ============================================


-- ============================================
-- 2. RECOVERY (ROLLBACK)
-- ============================================
-- Scenario:
--   A payment processing error occurs mid-update.
--   The system must roll back the incorrect charge
--   to restore the original payment amount.
-- ============================================

BEGIN TRANSACTION;

-- Mistakenly overcharge Rider on Payment 18 (Trip 18, Cash, currently 70.00 EGP)
UPDATE Payment
SET Amount = Amount + 500
WHERE PaymentID = 18;

-- Inspect the incorrectly updated record before rollback
SELECT PaymentID, Amount, PaymentStatus, PaymentMethod
FROM Payment
WHERE PaymentID = 18;
-- Expected: 570.00 EGP  ← incorrect

ROLLBACK TRANSACTION;

-- Inspect the record after rollback
SELECT PaymentID, Amount, PaymentStatus, PaymentMethod
FROM Payment
WHERE PaymentID = 18;
-- Expected: 70.00 EGP  ← original value restored

-- ============================================
-- Explanation:
--   ROLLBACK undoes all changes made within the
--   transaction before it was committed.
--   The Payment table is restored to its original
--   state, ensuring data integrity even when
--   application-level errors occur mid-transaction.
-- ============================================


-- ============================================
-- 3. SYSTEM FAILURE RECOVERY
-- ============================================
-- SQL Server uses a Write-Ahead Transaction Log (WAL).
--
--   If a system failure occurs BEFORE COMMIT:
--       The UNDO phase rolls back all incomplete
--       transactions — changes are discarded.
--
--   If a system failure occurs AFTER COMMIT:
--       The REDO phase replays all committed
--       transactions from the log — changes are
--       guaranteed to persist.
--
-- Example in this system:
--   If SQL Server crashes while Driver 1 is being
--   assigned to a new Request, the partial update
--   to the Trip and Driver tables is automatically
--   rolled back on restart — the driver's Status
--   stays 'Available' and no ghost Trip record
--   is left behind.
--
-- This guarantees the ACID properties:
--   Atomicity   — all-or-nothing execution
--   Consistency — schema constraints always hold
--   Isolation   — concurrent sessions don't interfere
--   Durability  — committed data survives failures
-- ============================================